# PARM

PLANNING PROJET PARM:
https://docs.google.com/spreadsheets/d/1YkHqiJ0XEDhe_I4bV5uQFyyVcEDD0d3Zy9wRoqBbg3w/edit#gid=0

ALU ET BANC DE REGISTRES / complet.

CONTROLLER /  non complet.
              - Load Store 
              - Shift, Add, Sub, Move
              
ASSEMBLEUR / complet.

PRESENTATION / en cours.

TESTS/ en cours.
